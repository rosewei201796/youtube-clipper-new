import pymysql,sys,time
from flask import Flask, jsonify, request
from functools import wraps

app = Flask(__name__)

# 添加API密钥配置
API_KEY = "test"  # 你可以设置你自己的密钥

def require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        api_key = request.headers.get('X-API-Key')
        if api_key and api_key == API_KEY:
            return f(*args, **kwargs)
        else:
            return jsonify({
                'code': 403,
                'message': '无效的API密钥',
                'data': None
            }), 403
    return decorated_function

def mysql_handle(ip,username,pwd,dbname,sqlcmd):
    # 建立连接
    conn = pymysql.connect(host=ip,
                           port=3306,
                           user=username,
                           password=pwd,
                           database=dbname,
                           charset='utf8')    # 执行操作（先获取游标对象，再执行sql语句）
    cursor = conn.cursor()  # 获取游标对象

    #cursor.execute("show tables;")



    
    #cursor = conn.cursor()
    #cursor.execute('CREATE TABLE %s(name varchar(30) primary key,id int)' % 'DSGTEST1')
    cursor.execute(sqlcmd)
    return cursor.fetchall()
    
def query_sql(sqlcmd):
    out = mysql_handle("yzg888.rwlb.rds.aliyuncs.com",'sting','yzg@test123',"lyrics",sqlcmd)
    return out    
    
def parse_lrc(lrc_text):
    """解析LRC歌词文本，返回包含时间和歌词的列表"""
    if not lrc_text:
        return []
    
    lrc_list = []
    lines = lrc_text.split('\n')
    
    for line in lines:
        line = line.strip()
        if not line or not line.startswith('['):
            continue
            
        try:
            time_end = line.find(']')
            if time_end == -1:
                continue
                
            time_str = line[1:time_end]
            lyrics = line[time_end + 1:].strip()
            
            if not lyrics:  # 跳过空歌词
                continue
                
            time_parts = time_str.split(':')
            if len(time_parts) == 2:
                minutes = float(time_parts[0])
                seconds = float(time_parts[1])
                time_seconds = minutes * 60 + seconds
                
                lrc_list.append({
                    "time": time_seconds,
                    "lineLyric": lyrics
                })
        except:
            continue
            
    return lrc_list

def get_lyrics_from_db():
    """从数据库获取并解析所有歌词"""
    sql_cmd = "SELECT id, title, lrc FROM main"
    results = query_sql(sql_cmd)
    
    all_lyrics = {}
    for row in results:
        song_id = row[0]
        title = row[1]
        lrc = row[2]
        
        parsed_lrc = parse_lrc(lrc)
        all_lyrics[song_id] = {
            'title': title,
            'lrclist': parsed_lrc
        }
    
    return all_lyrics

@app.route('/api/lyrics', methods=['GET'])
#@require_api_key
def get_all_lyrics():
    """获取所有歌词的API接口"""
    try:
        lyrics_data = get_lyrics_from_db()
        return jsonify({
            'code': 0,
            'message': 'success',
            'data': lyrics_data
        })
    except Exception as e:
        return jsonify({
            'code': -1,
            'message': str(e),
            'data': None
        })

@app.route('/api/lyrics/<int:song_id>', methods=['GET'])
#@require_api_key
def get_song_lyrics(song_id):
    """获取指定歌曲歌词的API接口"""
    try:
        lyrics_data = get_lyrics_from_db()
        if song_id in lyrics_data:
            return jsonify({
                'code': 0,
                'message': 'success',
                'data': lyrics_data[song_id]
            })
        else:
            return jsonify({
                'code': -1,
                'message': '未找到该歌曲',
                'data': None
            })
    except Exception as e:
        return jsonify({
            'code': -1,
            'message': str(e),
            'data': None
        })

@app.route('/api/lyrics/title/<string:song_title>', methods=['GET'])
#@require_api_key
def get_lyrics_by_title(song_title):
    """通过歌曲名称获取歌词的API接口"""
    try:
        # 构建SQL查询语句，使用LIKE进行模糊匹配
        sql_cmd = f"SELECT id, title, lrc FROM main WHERE title LIKE '%{song_title}%'"
        results = query_sql(sql_cmd)
        
        if not results:
            return jsonify({
                'code': -1,
                'message': '未找到相关歌曲',
                'data': None
            })
            
        # 处理所有匹配的歌曲
        matched_songs = []
        for row in results:
            song_id = row[0]
            title = row[1]
            lrc = row[2]
            
            parsed_lrc = parse_lrc(lrc)
            matched_songs.append({
                'id': song_id,
                'title': title,
                'lrclist': parsed_lrc
            })
        
        return jsonify({
            'code': 0,
            'message': 'success',
            'data': matched_songs
        })
        
    except Exception as e:
        return jsonify({
            'code': -1,
            'message': str(e),
            'data': None
        })

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)