# -*- coding: utf-8 -*-
import pymysql,sys,time
import argparse
import random
import json
from flask import Flask, jsonify,request

def mysql_handle(ip,username,pwd,dbname,sqlcmd):
    # 建立连接
    conn = pymysql.connect(host=ip,
                           port=3306,
                           user=username,
                           password=pwd,
                           database=dbname,
                           charset='utf8')    # 执行操作（先获取游标对象，再执行sql语句）
    cursor = conn.cursor()  # 获取游标对象

    #cursor.execute("show tables;")



    
    #cursor = conn.cursor()
    #cursor.execute('CREATE TABLE %s(name varchar(30) primary key,id int)' % 'DSGTEST1')
    cursor.execute(sqlcmd)
    return cursor.fetchall()

def query_sql(sqlcmd):
    out = mysql_handle("127.0.0.1",'root','1234',"nideshop",sqlcmd)
    return out

app = Flask(__name__)

@app.route('/')
def index():
    data = {
        "large_number": 12345678901234567890
    }
    return getindex()
    
@app.route('/api/index/index')
def getindex():
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    
    #获取BANNER信息
    sql = "SELECT * FROM `nideshop_ad` WHERE ( `ad_position_id` = 1 )"
    out = query_sql(sql)
    banner = {}
    bannerlist = []
    bannertitle = ["id","ad_position_id","media_type","name","link","image_url","content", "end_time","enabled"]
    #banner['id']
    
    for i in out:
        for z in range(0,len(i)):
            banner[bannertitle[z]] = i[z]
        bannerlist.append(banner)
        banner = {}
    #print (bannerlist) 
    data['data']['banner'] = bannerlist
    
    #获取channle信息
    channel = {}
    channellist = []
    channeltitle = ["id","name","img_url","sort_order","url","icon_url"]
    
    sql = "select nideshop_category.id,nideshop_category.name,nideshop_category.img_url,nideshop_category.sort_order,nideshop_channel.url,nideshop_category.icon_url from nideshop_category inner join nideshop_channel  WHERE (nideshop_category.parent_id = 0) AND ( nideshop_category.name != '推荐' ) AND (nideshop_category.show_index = nideshop_channel.id) ;"
    out = query_sql(sql)
    #print ("out",out)
    for i in out:
        for z in range(0,len(i)):
            channel[channeltitle[z]] = i[z]
        channellist.append(channel)
        channel = {}    
    data['data']['channel'] = channellist
    
    #获取新品首发
    newgoods = {}
    newgoodsList = []
    newgoodstitle = ["id","name","list_pic_url","retail_price"]
    
    sql = "SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `is_new` = 1 ) LIMIT 4"
    out = query_sql(sql)
    
    
    for i in out:
        for z in range(0,len(i)):
            newgoods[newgoodstitle[z]] = i[z]
        newgoodsList.append(newgoods)
        newgoods = {}    
    data['data']['newGoodsList'] = newgoodsList
    
    
    
    #获取最热数据
    hotgoods =  {}
    hotgoodsList = []
    hotgoodstitle = ["id","name","list_pic_url","retail_price","goods_brief"]
    
    sql = "SELECT `id`,`name`,`list_pic_url`,`retail_price`,`goods_brief` FROM `nideshop_goods` WHERE ( `is_hot` = 1 ) LIMIT 3"
    out = query_sql(sql)
    
    
    for i in out:
        for z in range(0,len(i)):
            hotgoods[hotgoodstitle[z]] = i[z]
        hotgoodsList.append(hotgoods)
        hotgoods = {}    
    data['data']['hotGoodsList'] = hotgoodsList
    
    
    #获取brandlist
    banner ={}
    bannerList = []
    bannertitle = ["id","name","list_pic_url","simple_desc","pic_url","sort_order","is_show","floor_price","app_list_pic_url","is_new","new_pic_url","new_sort_order"]
    
    sql = " SELECT * FROM `nideshop_brand` WHERE ( `is_new` = 1 ) ORDER BY `new_sort_order` asc"
    out = query_sql(sql)
    
    for i in out:
        for z in range(0,len(i)):
            banner[bannertitle[z]] = i[z]
        bannerList.append(banner)
        banner = {}    
    data['data']['brandList'] = bannerList
  
  
    #获取toplist
    topic = {}
    topicList = []
    topictitle = ["id","title","content","avatar","item_pic_url","subtitle","topic_category_id","price_info","read_count","scene_pic_url","topic_template_id","topic_tag_id","sort_order","is_show"]
    
    sql = " SELECT * FROM `nideshop_topic`  LIMIT 3"
    out = query_sql(sql)
    
    for i in out:
        for z in range(0,len(i)):
            topic[topictitle[z]] = i[z]
        topicList.append(topic)
        topic = {}    
    data['data']['topicList'] = topicList
    
    
    
    #获取产品类目list
    category = {}
    categoryList = []
    categorytitle = ["id","name"]
    cateitemlist = ['1005000','1005001','1005002','1008000','1010000','1011000','1012000','1013001','1019000']
    
    
    subcatedict ={}
    goodslist = []
    
    #for cateitem in cateitemlist:
    sql = " select id,name FROM `nideshop_category` WHERE ( `parent_id` = 0) "
    out = query_sql(sql)
    
    #subsql = 
    #print (out)
    for i in out:
        for z in range(0,len(i)):
           category[categorytitle[z]] = i[z]
        categoryList.append(category)
        
        category = {}
    print ("cate:",categoryList)    
    
    
    for item in categoryList:
        subsql = " select id FROM `nideshop_category` WHERE ( `parent_id` = {}) ".format(item['id'])
        goodsout =   query_sql(subsql)  
        
        goodsout = [str(x[0]) for x in goodsout]
        goodsout = ','.join(goodsout)
        #print (goodsout)
        sql = "SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `category_id` IN ({0}) ) limit 7".format(goodsout)
        print (sql)
        out = query_sql(sql)
        #print (out)
        for subitem in out:
            subcatedict["id"] = subitem[0]
            subcatedict["name"] =  subitem[1]
            subcatedict["list_pic_url"] = subitem[2]
            subcatedict["retail_price"] = subitem[3]
            print ("sub:",subcatedict)
            goodslist.append(subcatedict)   
            subcatedict = {}
        item['goodsList'] = goodslist
        goodslist = []
            
        #print (out)
        
    data['data']['categoryList'] = categoryList
    return jsonify(data)    
    
#demo    
@app.route('/user/<username>')
def show_user_profile(username):
    # 这里的username就是通过路由传递的参数
    return f'User {username}'    

#demo
@app.route('/get_data')
def get_data():
    param1 = request.args.get('categoryId')
    param2 = request.args.get('page')
    # 使用param1和param2
    return f"Param1: {param1}, Param2: {param2}"

#获取商品类目信息
@app.route('/api/goods/category')    
def get_cate_info():
    cateid = request.args.get('id')
    currentCategory = {}
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    sql = "	SELECT name,front_name,id FROM `nideshop_category` WHERE ( `id` = '{}' )".format(cateid)
    out = query_sql(sql)
    #print (sql)
    #print (out)
    if len(out) > 0:
        currentCategory['name'] = out[0][0]
        currentCategory['front_name'] = out[0][1]
        currentCategory['id'] = out[0][2]
        data['data']['currentCategory'] = currentCategory
    #print (out)
    
    #获取产品类目

    brotherCategory = {}
    brotherCategoryList = []
    brotherCategorytitle = ["name","front_name","id"]
    
    sql = "	SELECT name,front_name,id FROM `nideshop_category` WHERE ( `parent_id` = 0 )"
    out = query_sql(sql)
    
    for i in out:
        for z in range(0,len(i)):
            brotherCategory[brotherCategorytitle[z]] = i[z]
        brotherCategoryList.append(brotherCategory)
        brotherCategory = {}    
    data['data']['brotherCategory'] = brotherCategoryList

    return jsonify(data)    
    
    
def getrenqi():
    data = {
            "errno":0,
            "errmsg": "",
            "data": {}
        }
    data['data']['count'] =9
    data['data']['totalPages'] =12
    data['data']['pageSize'] =100
    data['data']['currentPage'] =1
    
    #horornew = 'is_hot' 'is_new'
    
    datalist = []
    tmpdic  = {}
 
    sql ='''SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `is_hot` = '1' ) ORDER BY `id` desc LIMIT 0,1000'''
    out =  query_sql(sql)
    
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['list_pic_url'] = item[2]
        tmpdic['retail_price'] = item[3]
        datalist.append(tmpdic)
        tmpdic = {}
    data['data']['data'] =datalist
        
    data['data']['goodsList'] =datalist  
    
    
    
    
    
    
    
    
    sql = " select id,name FROM `nideshop_category` WHERE ( `parent_id` = 0) "
    out = query_sql(sql)
    filterCategorylist = []
    tmpdict = {}
    print ("298:",out)
    for item in out:
        #print ("item:",item)
        tmpdic['id'] = str(item[0])
        tmpdic['name'] = item[1]
        tmpdic['checked'] = False
        print(tmpdic)    
        filterCategorylist.append(tmpdic) 
        print (filterCategorylist)
        tmpdic = {}     
    
    data['data']['filterCategory'] =filterCategorylist

    return jsonify(data)     
    
    
        
#获取商品列表信息    
@app.route('/api/goods/list')   
def get_goodslist():
    cateid = request.args.get('categoryId')
    bid = request.args.get('brandId')
    page = request.args.get('page')
    size = request.args.get('size')
    sort = request.args.get('sort')
    order = request.args.get('order')
    print ("choose:",cateid,bid)
       
    '''    
    elif sort:
        print ("sort sort")
        
    '''   
    if bid:
        return get_goodsdetail(bid)
 
    elif int(cateid) != 0:
        data = {
            "errno":0,
            "errmsg": "",
            "data": {}
        }
        data['data']['count'] =9
        data['data']['totalPages'] =page
        data['data']['pageSize'] =size
        data['data']['currentPage'] =1
        
        datalist = []
        tmpdic  = {}
        
        
        
        sql = " SELECT `id` FROM `nideshop_category` WHERE ( `parent_id` = '{}' ) LIMIT 10000".format(cateid)
        out = query_sql(sql)
        if len(out) == 0:
            cateid = cateid[:-1]+'0'
            sql = " SELECT `id` FROM `nideshop_category` WHERE ( `parent_id` = '{}' ) LIMIT 10000".format(cateid)
            out = query_sql(sql)
        #print ("out:",out)
        out = [str(x[0]) for x in out]
        out = ','.join(out)
        
        sql = " SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `category_id` IN ({}) ) ORDER BY `id` desc".format(out)
        out = query_sql(sql)
        
        for item in out:
            tmpdic['id'] = item[0]
            tmpdic['name'] = item[1]
            tmpdic['list_pic_url'] = item[2]
            tmpdic['retail_price'] = item[3]
            datalist.append(tmpdic)
            tmpdic = {}
        
        data['data']['data'] =datalist
        
        data['data']['goodsList'] =datalist
        
        sql = " select id,name FROM `nideshop_category` WHERE ( `parent_id` = 0) "
        out = query_sql(sql)
        filterCategorylist = []
        tmpdict = {}
        print ("298:",out)
        for item in out:
            #print ("item:",item)
            tmpdic['id'] = str(item[0])
            tmpdic['name'] = item[1]
            if cateid == str(item[0]):
                tmpdic['checked'] = True
            else:
                tmpdic['checked'] = False
            print(tmpdic)    
            filterCategorylist.append(tmpdic) 
            print (filterCategorylist)
            tmpdic = {}     
        
        data['data']['filterCategory'] =filterCategorylist
        return jsonify(data)     
    elif order == 'default':
        pass
    else:
        return getrenqi()
@app.route('/api/brand/list')    
def get_zhuanti():
    limit = request.args.get('page')
    psize = request.args.get('size') 
    limit = int(limit)*10
    
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    print ("limit:",limit)
    sql = ' SELECT COUNT(`nideshop_brand`.id) AS think_count FROM `nideshop_brand` LIMIT 1'
    out = query_sql(sql)
    data['data']['count'] = out[0][0]
    data['data']['totalPages'] = round(int(out[0][0])/10)
    data['data']['pageSize'] = 10
    data['data']['currentPage'] = 1
    
    sql = "SELECT `id`,`name`,`floor_price`,`app_list_pic_url` FROM `nideshop_brand` LIMIT {}".format(limit)
    print (sql)
    out = query_sql(sql)
    
    ztlist = []
    tmpdict = {}
    for i in out:
        tmpdict["id"] = i[0]
        tmpdict["name"] = i[1]
        tmpdict["floor_price"] = i[2]
        tmpdict["app_list_pic_url"] = i[3]
        ztlist.append(tmpdict)
        tmpdict = {}
    data['data']['data'] = ztlist
    return jsonify(data)    

@app.route('/api/brand/detail')    
def get_detailzt():    
    gid = request.args.get('id')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    sql = '''SELECT id,name,app_list_pic_url,simple_desc,list_pic_url FROM `nideshop_brand` WHERE ( `id` = '{}' ) LIMIT 1'''.format(gid)
    out = query_sql(sql)
    
    ztlist = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['app_list_pic_url'] = item[2]
        tmpdic['simple_desc'] = item[3]
        tmpdic['list_pic_url'] = item[4]
        ztlist.append(tmpdic)
        tmpdic = {}
    data['data']['brand'] = ztlist[0]   
    return jsonify(data)  
 
def get_goodsdetail(bid):
    #bid = request.args.get('brandId')
    #page = request.args.get('page')
    #size = request.args.get('size')
    
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    } 
    
    sql = '''SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `brand_id` = '{}' ) ORDER BY `id` desc LIMIT 0,1000'''.format(bid)
    out = query_sql(sql)
    print ("mysql:",sql)
    goodslist = []
    tmpdic = {}
    
    for i in out:
       tmpdic['id'] = i[0]
       tmpdic['name'] = i[1]
       tmpdic['list_pic_url'] = i[2]
       tmpdic['retail_price'] = i[3]
       goodslist.append(tmpdic)
       tmpdic = {}
    data['data']['goodsList'] = goodslist   
    return jsonify(data)  

#单个商品详细信息    
@app.route('/api/goods/detail')  
def get_detailinfo():
    gid = request.args.get('id')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    info = {}
    sql = '''SELECT id,name,goods_brief,goods_desc,list_pic_url,retail_price FROM `nideshop_goods` WHERE ( `id` = '{}' ) LIMIT 1'''.format(gid)
    out = query_sql(sql)
    
    info['id'] = out[0][0]
    info['name'] = out[0][1]
    info['goods_brief'] = out[0][2]
    info['goods_desc'] = out[0][3]
    info['list_pic_url'] = out[0][4]
    info['retail_price'] = out[0][5]
    data['data']['info'] = info  
    
    sql = "SELECT id,goods_id,img_url FROM `nideshop_goods_gallery` WHERE ( `goods_id` = '{}' ) LIMIT 4".format(gid)
    out = query_sql(sql)
    gallerylist = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['goods_id'] = item[1]
        tmpdic['img_url'] = item[2]
        gallerylist.append(tmpdic)
        tmpdic = {}
    data['data']['gallery'] = gallerylist  
    
    
    sql = '''
SELECT nideshop_goods_attribute.value,nideshop_attribute.name FROM `nideshop_goods_attribute` LEFT JOIN nideshop_attribute ON nideshop_goods_attribute.attribute_id=nideshop_attribute.id WHERE ( nideshop_goods_attribute.goods_id = '{}' ) ORDER BY nideshop_goods_attribute.id asc'''.format(gid)
    out = query_sql(sql)  
    attrlist = []
    tmpdic = {}
    for item  in out:
        tmpdic['value']=item[0]
        tmpdic['name']=item[1]
        attrlist.append(tmpdic)
        tmpdic = {}
    data['data']['attribute'] = attrlist      

    data['data']['userHasCollect'] = 0 

    sql = ' SELECT * FROM `nideshop_goods_issue`'    
    out = query_sql(sql)  
    issuelist = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['goods_id'] = item[1]
        tmpdic['question'] = item[2]
        tmpdic['answer'] = item[3]
        issuelist.append(tmpdic)
        tmpdic = {}
    data['data']['issue'] = issuelist     
    
    return jsonify(data)  

#商品菜单 中的相关产品
@app.route('/api/goods/related')  
def related_goods():
    gid = request.args.get('id')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    } 
    
    sql = ''' SELECT category_id FROM `nideshop_goods` WHERE ( `id` = '{}' ) LIMIT 1'''.format(gid)
    out = query_sql(sql)  
    cateid = out[0][0]
    sql = ''' SELECT `id`,`name`,`list_pic_url`,`retail_price` FROM `nideshop_goods` WHERE ( `category_id` = {} ) LIMIT 8'''.format(cateid)
    out = query_sql(sql)  
    
    glist = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['list_pic_url'] = item[2]
        tmpdic['retail_price'] = item[3]
        glist.append(tmpdic)
        tmpdic = {}
    data['data']['goodsList'] = glist     
    return jsonify(data)  
    
#严选好物
@app.route('/api/goods/hot')  
def yuanxuantitle():
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    bannerinfo = {}
    bannerinfo['url'] = ""
    bannerinfo['name'] = "大家都在买的严选好物"
    bannerinfo['img_url'] = "http://yanxuan.nosdn.127.net/8976116db321744084774643a933c5ce.png"
    
    data['data']['bannerInfo'] = bannerinfo 
    return jsonify(data)
    
    

#获取话题列表
@app.route('/api/topic/list')  
def gettopiclist():    
    page = request.args.get('page')
    pgsize = request.args.get('size')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    #data['data']['bannerInfo']
    sql = "SELECT COUNT(`nideshop_topic`.id) AS think_count FROM `nideshop_topic` LIMIT 1"
    print (sql)
    out = query_sql(sql)  
    data['data']['count'] = out[0][0]
    data['data']['totalPages'] = int(out[0][0])/10
    data['data']['pageSize'] = pgsize
    #data['data']['count'] = pgsize
    data['data']['currentPage']= page
    
    sql = 'SELECT `id`,`title`,`price_info`,`scene_pic_url`,`subtitle` FROM `nideshop_topic` LIMIT {},10'.format((int(page)-1)*10)
    print (sql,page,int(page)-1*10)
    out = query_sql(sql)
    
    outlist = []
    tmpdic = {}
    
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['title'] = item[1]
        tmpdic['price_info'] = item[2]
        tmpdic['scene_pic_url'] = item[3]
        tmpdic['subtitle'] = item[4]
        outlist.append(tmpdic)
        tmpdic = {}
    data['data']['data']= outlist    
    
    return jsonify(data)



#获取话题列表
@app.route('/api/topic/related')  
def getrelatedlist():    
    page = request.args.get('page')
    pgsize = request.args.get('size')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    sql = 'SELECT `id`,`title`,`price_info`,`scene_pic_url`,`subtitle` FROM `nideshop_topic` LIMIT 4'
    out = query_sql(sql)
    
    outlist = []
    tmpdic = {}
    
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['title'] = item[1]
        tmpdic['price_info'] = item[2]
        tmpdic['scene_pic_url'] = item[3]
        tmpdic['subtitle'] = item[4]
        outlist.append(tmpdic)
        tmpdic = {}
    data['data']= outlist   
    
    return jsonify(data)
    
    
    
    
#专题页面相关产品简介  
@app.route('/api/topic/detail')   
def get_related():
    ida = request.args.get('id')
    
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    sql = '''SELECT * FROM `nideshop_topic` WHERE ( `id` = '{}' ) LIMIT 1'''.format(ida)
    out = query_sql(sql)

    outlist = []
    tmpdic = {}
    for itme in out:
        tmpdic['id'] = itme[0]
        tmpdic['title'] = itme[1]
        tmpdic['content'] = itme[2]
        tmpdic['avatar'] = itme[3]
        tmpdic['item_pic_url'] = itme[4]
        tmpdic['subtitle'] = itme[5]
        tmpdic['topic_category_id'] = itme[6]
        tmpdic['price_info'] = itme[7]
        tmpdic['read_count'] = itme[8]
        tmpdic['scene_pic_url'] = itme[9]
        tmpdic['topic_template_id'] = itme[10]
        tmpdic['topic_tag_id'] = itme[11]
        tmpdic['sort_order'] = itme[12]
        tmpdic['is_show'] = itme[13]
        outlist.append(tmpdic)
        #tmpdic = {}
    data['data']= tmpdic   
    return jsonify(data)
    
    
    
@app.route('/api/goods/count')       
def getgoodscount():
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    sql ='''SELECT COUNT(`id`) AS think_count FROM `nideshop_goods` WHERE ( `is_delete` = 0 ) AND ( `is_on_sale` = 1 ) LIMIT 1'''
    out = query_sql(sql)
    data['data']['goodsCount']= out[0][0]
    return jsonify(data)
        
    
    
@app.route('/api/catalog/index')       
def getgoodscate():
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }
    
    
    
    sql = 'SELECT id,name,front_name,wap_banner_url FROM `nideshop_category` WHERE ( `parent_id` = 1005000 )'
    out = query_sql(sql)    
    subCategoryList = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['front_name'] = item[2]
        tmpdic['wap_banner_url'] = item[3]
        subCategoryList.append(tmpdic)
        tmpdic = {}
    #categoryList[0][]    
    
    sql = 'SELECT id,name,front_name,wap_banner_url FROM `nideshop_category` WHERE ( `parent_id` = 0 ) LIMIT 10'
    out = query_sql(sql)    
    
    
    categoryList =[]
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['front_name'] = item[2]
        tmpdic['wap_banner_url'] = item[3]
        if '1005000' in str(item[0]):
            tmpdic['subCategoryList'] = subCategoryList
        categoryList.append(tmpdic)
        tmpdic = {}
    
    data['data']['categoryList']= categoryList
    data['data']['currentCategory']= categoryList[0]
    return jsonify(data)
    
@app.route('/api/catalog/current')       
def getgoodscurrent():
    cid = request.args.get('id')
    data = {
        "errno":0,
        "errmsg": "",
        "data": {}
    }

    sql = 'SELECT id,name,front_name,wap_banner_url FROM `nideshop_category` WHERE ( `parent_id` = {} ) LIMIT 10'.format(cid)
    out = query_sql(sql)   

    subCategoryList = []
    tmpdic = {}
    for item in out:
        tmpdic['id'] = item[0]
        tmpdic['name'] = item[1]
        tmpdic['front_name'] = item[2]
        tmpdic['wap_banner_url'] = item[3]
        subCategoryList.append(tmpdic)
        tmpdic = {}    
        
    sql= '''SELECT id,name,front_name,wap_banner_url FROM `nideshop_category` WHERE ( `id` = '{}' ) LIMIT 1'''.format(cid)
    out = query_sql(sql)    

    currentCategory = {}
    currentCategory['id'] = out[0][0]
    currentCategory['name'] = out[0][1]
    currentCategory['front_name'] = out[0][2]
    currentCategory['wap_banner_url'] = out[0][3]
    currentCategory['subCategoryList'] = subCategoryList
    
    data['data']['currentCategory']= currentCategory
    return jsonify(data)
    
    
if __name__ == '__main__':
    sqlcmd = "select * from nideshop_attribute"
    out = query_sql(sqlcmd)
    
    #print (out)
    app.run(port=8360)
   # count = cursor.execute('SELECT * FROM %s' %'DSGTEST')
   # count = cursor.execute('SELECT * FROM %s' %'DSGTEST')



