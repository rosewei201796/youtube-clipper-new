-- --------------------------------------------------------
-- 主机:                           yzg888.rwlb.rds.aliyuncs.com
-- 服务器版本:                        8.0.13 - Source distribution
-- 服务器操作系统:                      Linux
-- HeidiSQL 版本:                  12.8.0.6908
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- 导出 lyrics 的数据库结构
CREATE DATABASE IF NOT EXISTS `lyrics` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `lyrics`;

-- 导出  表 lyrics.artist 结构
CREATE TABLE IF NOT EXISTS `artist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `introduce` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `name` (`name`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=75153 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在导出表  lyrics.artist 的数据：~0 rows (大约)

-- 导出  表 lyrics.main 结构
CREATE TABLE IF NOT EXISTS `main` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `artists` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `album` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `hash` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lrc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cover` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `hash` (`hash`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=316233 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在导出表  lyrics.main 的数据：~1 rows (大约)
INSERT INTO `main` (`id`, `title`, `artists`, `album`, `hash`, `lrc`, `cover`) VALUES
	(1, 'Dynamite (RetroVision Flip)', 'RetroVision&Taio Cruz', 'Dynamite (RetroVision Flip)', '2502bc2ec64e54d6264df1cbd65c000', '[00:01.256] I throw my hands up in the air sometimes\n[00:04.213] Saying, "Ayo", gotta let go\n[00:08.617] I wanna celebrate and live my life\n[00:11.585] Saying, "Ayo", baby, let\'s go\n[00:15.107] \'Cause we gon\' rock this club\n[00:17.180] We gon\' go all night\n[00:19.021] We gon\' light it up\n[00:20.820] Like it\'s dynamite\n[00:22.686] \'Cause I told you once\n[00:24.579] Now I told you twice\n[00:26.440] We gon\' light it up\n[00:28.201] Like it\'s dynamite\n[00:30.569] Hands in the air\n[00:32.411] Hands, hands in the air\n[00:33.774] Put your hands in the air—\n[00:44.165] I\'m gonna put my hands\n[00:45.309]\n[00:55.913] Saying, "Ayo", gotta let go\n[01:00.107]\n[01:10.708] Saying, "Ayo", gotta let go\n[01:15.084] I\'m gonna take it all, I\n[01:18.795] I\'m gonna be the last one standing\n[01:22.659] Higher over all, I\n[01:26.158] I\'m gonna be the last one landing\n[01:29.408] \'Cause I, I, I believe it\n[01:33.077] And I, I, I, I just want it all\n[01:37.708] I just want it all\n[01:39.557] I\'m gonna put my hands in the air\n[01:42.562] Hands, hands in the air\n[01:44.608] I throw my hands up in the air sometimes\n[01:47.619] Saying, "Ayo", gotta let go\n[01:51.950] I wanna celebrate and live my life\n[01:54.936] Saying, "Ayo", baby, let\'s go\n[01:58.465] \'Cause we gon\' rock this club\n[02:00.566] We gon\' go all night\n[02:02.366] We gon\' light it up\n[02:04.168] Like it\'s dynamite\n[02:06.064] \'Cause I told you once\n[02:07.921] Now I told you twice\n[02:09.789] We gon\' light it up\n[02:11.540] Like it\'s dynamite\n[02:13.298] \'Cause we gon\' rock this club\n[02:15.296] We gon\' go all night\n[02:17.152] We gon\' light it up\n[02:18.967] Like it\'s dynamite\n[02:20.833] \'Cause I told you once\n[02:22.681] Now I told you twice\n[02:24.508] We gon\' light it up\n[02:26.332] Like it\'s dynamite\n[02:28.689]\n[02:39.261] Saying, "Ayo", gotta let go\n[02:43.456]\n[02:54.022] Saying, "Ayo", gotta let go\n[02:57.749] We gon\' rock this club\n[02:59.604] We gon\' go all night\n[03:01.468] We gon\' light it up\n[03:03.264] Like it\'s dynamite\n[03:05.128] \'Cause I told you once\n[03:06.992] Now I told you twice\n[03:08.848] We gon\' light it up\n[03:10.658] Like it\'s dynamite\n[03:13.016]\n', 'http://p1.music.126.net/G0YVVYCBAj9OpwrrOslm9g==/109951168272144504.jpg');

-- 导出  表 lyrics.metadata 结构
CREATE TABLE IF NOT EXISTS `metadata` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `metaname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `value` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `metaname` (`metaname`),
  KEY `metaname_index` (`metaname`),
  KEY `type_index` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 正在导出表  lyrics.metadata 的数据：~0 rows (大约)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
