from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from yt_dlp import YoutubeDL
import os
import tempfile
import logging
import shutil
import re
import subprocess

app = Flask(__name__)
CORS(app)

# 添加日志配置
logging.basicConfig(level=logging.DEBUG)

# 确保下载目录存在
DOWNLOAD_DIR = os.path.join(os.path.expanduser("~"), "Downloads", "YouTube_Downloads")
os.makedirs(DOWNLOAD_DIR, exist_ok=True)

@app.route('/download', methods=['POST'])
def download_video():
    temp_dir = None
    try:
        logging.info("收到下载请求")
        data = request.json
        logging.info(f"请求数据: {data}")
        
        video_url = data['video_url']
        start_time = float(data.get('start_time', 0))
        end_time = float(data.get('end_time', 0))
        file_name = data['file_name']
        
        # 更严格的文件名清理
        def clean_filename(filename):
            cleaned = re.sub(r'[^\u4e00-\u9fff\w\s-]', '', filename)
            cleaned = re.sub(r'\s+', ' ', cleaned)
            if not cleaned:
                cleaned = 'video'
            return cleaned.strip()

        file_name = clean_filename(file_name)
        logging.info(f"清理后的文件名: {file_name}")
        
        # 创建临时目录
        temp_dir = tempfile.mkdtemp()
        final_output_path = os.path.join(DOWNLOAD_DIR, f"{file_name}.mp4")
        
        # 计算持续时间
        duration = end_time - start_time
        if duration <= 0:
            raise ValueError("结束时间必须大于开始时间")

        # 使用yt-dlp直接下载指定时间段的视频
        ydl_opts = {
            'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
            'outtmpl': final_output_path,
            'quiet': False,
            'no_warnings': True,
            'download_ranges': lambda info: [[start_time, end_time]],
            'force_keyframes_at_cuts': True,
            'http_headers': {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            }
        }
        
        logging.info("开始下载指定时间段的视频")
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([video_url])
        logging.info("视频下载完成")

        return jsonify({
            "status": "success",
            "message": f"视频已下载到: {final_output_path}",
            "file_path": final_output_path
        })

    except Exception as e:
        logging.error(f"处理过程中出错: {str(e)}", exc_info=True)
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
    finally:
        # 清理临时文件
        if temp_dir and os.path.exists(temp_dir):
            try:
                shutil.rmtree(temp_dir)
            except Exception as e:
                logging.error(f"清理临时文件失败: {str(e)}")

# 添加新的路由用于获取视频列表
@app.route('/videos', methods=['GET'])
def get_videos():
    try:
        videos = []
        for filename in os.listdir(DOWNLOAD_DIR):
            if filename.endswith('.mp4'):
                file_path = os.path.join(DOWNLOAD_DIR, filename)
                videos.append({
                    'title': filename.replace('.mp4', ''),
                    'path': file_path
                })
        return jsonify(videos)
    except Exception as e:
        logging.error(f"获取视频列表时出错: {str(e)}")
        return jsonify({'error': str(e)}), 500

# 添加新的路由用于播放视频
@app.route('/play/<path:video_path>')
def play_video(video_path):
    try:
        return send_file(video_path, mimetype='video/mp4')
    except Exception as e:
        logging.error(f"播放视频时出错: {str(e)}")
        return str(e), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
