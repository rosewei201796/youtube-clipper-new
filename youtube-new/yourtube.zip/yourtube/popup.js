document.addEventListener('DOMContentLoaded', async () => {
  const startTimeSlider = document.getElementById('startTimeSlider');
  const endTimeSlider = document.getElementById('endTimeSlider');
  const startTimeLabel = document.getElementById('startTimeLabel');
  const endTimeLabel = document.getElementById('endTimeLabel');

  // 更新标签显示滑块值
  startTimeSlider.addEventListener('input', () => {
    startTimeLabel.textContent = startTimeSlider.value;
  });

  endTimeSlider.addEventListener('input', () => {
    endTimeLabel.textContent = endTimeSlider.value;
  });

  // 获取当前活动标签页的URL和标题
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab.url.includes('youtube.com/watch') || tab.url.includes('youtube.com/shorts')) {
      document.getElementById('videoUrl').value = tab.url;
      document.getElementById('fileName').value = tab.title.replace(' - YouTube', '');
    }
  } catch (error) {
    console.error('Error fetching tab info:', error);
  }

  document.getElementById('downloadBtn').addEventListener('click', async () => {
    const videoUrl = document.getElementById('videoUrl').value;
    const startTime = parseFloat(startTimeSlider.value);
    const endTime = parseFloat(endTimeSlider.value);
    const fileName = document.getElementById('fileName').value;

    if (!videoUrl) {
      alert('请输入YouTube视频网址');
      return;
    }

    if (endTime <= startTime) {
      alert('结束时间必须大于开始时间');
      return;
    }

    try {
      const downloadBtn = document.getElementById('downloadBtn');
      downloadBtn.textContent = '处理中...';
      downloadBtn.disabled = true;

      const response = await fetch('http://localhost:5000/download', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          video_url: videoUrl,
          start_time: startTime,
          end_time: endTime,
          file_name: fileName
        })
      });

      const result = await response.json();

      if (response.ok) {
        alert(`视频下载成功！\n\n文件保存在：${result.file_path}`);
      } else {
        throw new Error(result.message || '下载请求失败');
      }
    } catch (error) {
      console.error('Error:', error);
      alert('发生错误：' + error.message);
    } finally {
      const downloadBtn = document.getElementById('downloadBtn');
      downloadBtn.textContent = '下载视频';
      downloadBtn.disabled = false;
    }
  });
}); 